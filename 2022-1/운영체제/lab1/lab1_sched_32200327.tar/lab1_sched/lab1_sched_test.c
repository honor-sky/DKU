/*
 * *	DKU Operating System Lab
 * *	    Lab1 (Scheduler Algorithm Simulator)
 * *	    Student id : 32200327 
 * *	    Student name : 김경민 
 * *
 * *   lab1_sched.c :
 * *       - Lab1 source file.
 * *       - Must contains scueduler algorithm test code.
 * *
 * */

#include <aio.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <errno.h>
#include <time.h>
#include <sys/time.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <assert.h>
#include <pthread.h>
#include <asm/unistd.h>

#include "lab1_sched_types.h"


/*
 * you need to implement scheduler simlator test code.
 *  
 */

//typedef struct _process Pro;
typedef struct _process {
	int number;
	int arrive_t;
	int service_t;
	int process_t;
}Pro;

int main(int argc, char *argv[]){
	

        Pro *pArr;
	int p_num;

	// input process amount 
	printf("생성할 프로세스 개수를 입력하세요: ");
	scanf("%d", &p_num);
	pArr = (Pro*)malloc(sizeof(Pro) * p_num);

	int i;
	for (i = 0; i < p_num; i++) {
		pArr[i].number = i + 1;
		printf("%d번 프로세스 도착시간을 입력하시오: ",i+1);
		scanf("%d", &pArr[i].arrive_t);
		printf("%d번 프로세스 서비스시간을 입력하시오: ", i + 1);
		scanf("%d", &pArr[i].service_t);
		pArr[i].process_t = 0;
	}
	printf("\n");

        //call schduling algorithm

	printf("FCFS\n");
	FCFS(pArr, p_num);
	printf("\n");

	printf("SPN\n");
	SPN(pArr, p_num);
	printf("\n");

	printf("RR\n");
	RR(pArr, p_num,1);
	printf("\n");

	printf("HRRN\n");
	HRRN(pArr, p_num);
	printf("\n");

	free(pArr);



}



