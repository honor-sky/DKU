#include <aio.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <errno.h>
#include <time.h>
#include <sys/time.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <assert.h>
#include <pthread.h>
#include <asm/unistd.h>

#include "lab1_sched_types.h"

/*
 *  you need to implement FCFS, RR, SPN, HRRN, MLFQ scheduler.
*/


typedef struct _process{
	int number;    // process number (just input sequence)
	int arrive_t;  // arrival time
	int service_t; // service time
	int process_t; // sum of processing time
} Pro;


static int p_num;

int  arrival_sort(const void* a, const void* b) {
	   if ((*(Pro*)a).arrive_t >= (*(Pro*)b).arrive_t){
		   return 1;
	   }
	   else if ((*(Pro*)a).arrive_t < (*(Pro*)b).arrive_t){
		    return -1;
	   }
	   else{
		   return 0;
	   }
		    
}

void FCFS(Pro *proc_arr,int p) {
	init(proc_arr, p);
	p_num = p;

	qsort(proc_arr, p_num, sizeof(Pro), arrival_sort);

	 int i, j,k;
	 int total = 0;
	  for (i = 0; i < p_num; i++) {
		  printf("%d번 프로세스: ", proc_arr[i].number);

		  //이미 지나간 시간
		  for (j = 0; j < total; j++) {
	               printf("ㅁ");
	          }
		  //도착시간이 total보다 큰 경우
		  if (total < proc_arr[i].arrive_t) {
			  for (k = 0; k < proc_arr[i].arrive_t - total; k++) {
				  printf("ㅁ");
		           }
		  }

		  for(j = 0; j < proc_arr[i].service_t; j++) {
			  printf("■");
			  total++; 
		  }
		  printf("\n");
	 }
}

void SPN(Pro *proc_arr, int p) {
	 init(proc_arr, p);
         p_num = p;
	
	 qsort(proc_arr, p_num, sizeof(Pro), arrival_sort);

	 int i, j, k;
	 int total = proc_arr[0].arrive_t;

	for (i = 0; i < p_num; i++) {
	        int min_service_t = 99999;
	        int min_idx = 0;
	        int count = 0;

	         for (j = 0; j < p_num; j++) {
			if (proc_arr[j].process_t != proc_arr[j].service_t) { 
				if (total >= proc_arr[j].arrive_t) { 
					count++;
					 if (min_service_t > proc_arr[j].service_t) {
						 min_service_t = proc_arr[j].service_t;
						 min_idx = j;
					 }

				 }
			 }
		 } 

		 if (count == 0) {
			 printf("%d번 프로세스: ", proc_arr[i].number);

			 for (j = 0; j < total; j++) {
				 printf("ㅁ");
			 }
			 for (k = 0; k < proc_arr[i].arrive_t - total+1; k++) {
				 printf("ㅁ");
				 total++;
				 (proc_arr[i].process_t)++; 
			 }
		 }else{
			 printf("%d번 프로세스: ", proc_arr[min_idx].number);

			 for (j = 0; j < total; j++) {
				 printf("ㅁ");
			 }

			 if (total < proc_arr[i].arrive_t) {
				 for (k = 0; k < proc_arr[i].arrive_t - total; k++) {
					 printf("ㅁ");
					 total++;
				 }
			 }

			  for (j = 0; j < min_service_t; j++) {
				   printf("■");
				   total++;
				   (proc_arr[min_idx].process_t)++;
			 }
		 }
          printf("\n");
	}
}





void RR(Pro *proc_arr, int p, int Q) {
	 init(proc_arr, p);
         int p_num = p;
	 int i, j;
	 int time_s = Q;
	 int total = 0;

	 qsort(proc_arr, p_num, sizeof(Pro), arrival_sort);

	 int sum = 0;
	 int sum_proc = 0;
	 for (i = 0; i < p_num; i++) {
		 sum += proc_arr[i].service_t;
	 }
	 sum_proc = sum;

	 int list[100];
	 int list_cnt = 0;
	 int ready_cnt = 0;
	 int readyQ[100];


	 while (sum_proc != 0) {
		 

		 //레디큐
		 for (j = 0; j < p_num; j++) {
			 if (proc_arr[j].arrive_t == total) {
				 readyQ[ready_cnt] = proc_arr[j].number;
				 ready_cnt++;
				 proc_arr[j].process_t++;
			 }
		 }

		 for (j = 0; j < p_num; j++) {
			 if (proc_arr[j].arrive_t < total) {
				 if (((proc_arr[j].process_t) != (proc_arr[j].service_t)) && (list[list_cnt - 1] == proc_arr[j].number)) {
					 readyQ[ready_cnt] = proc_arr[j].number;
					 ready_cnt++;
					 proc_arr[j].process_t++;
				 }
			 }
		 }

		 //수행큐
		 for (i = 0; i < time_s; i++) {
			 list[list_cnt] = readyQ[list_cnt];
			 total++;
			 sum_proc--;
		 }
		 list_cnt++;
	}

	print_simulation(list, list_cnt,p);
}


void HRRN(Pro *proc_arr, int p) {
	init(proc_arr, p);
	int p_num = p;

	int i, j;
	int total = 0;

	int list[100];
	int list_cnt = 0;
	int p_count=0;

	int sum = 0;
	int sum_proc = 0;
	for (i = 0; i < p_num; i++) {
		sum += proc_arr[i].service_t;
	}
	sum_proc = sum;

	qsort(proc_arr, p_num, sizeof(Pro), arrival_sort);

	while (sum_proc != 0) {
		int flag=0;
		int max=0;
		int idx=0;

		for (i = 0; i < p_num; i++) {
			if (proc_arr[i].arrive_t <= total) {
				if ((proc_arr[i].process_t) != (proc_arr[i].service_t)) {
					if (max < (((total - proc_arr[i].arrive_t) + proc_arr[i].service_t) / proc_arr[i].service_t)) {

						max = (((total - proc_arr[i].arrive_t) + proc_arr[i].service_t) / proc_arr[i].service_t);
						idx=i;
						flag=1;
					}
				}
			}
		}

		if (flag == 1) {
			for (i = 0; i < proc_arr[idx].service_t; i++) {
				list[list_cnt] = proc_arr[idx].number;

				(proc_arr[idx].process_t)++;
				list_cnt++;
				total++;
				sum_proc--;
				flag=1;
			}
			p_count++;
		}else{
			for (i = 0; i < (proc_arr[i].arrive_t - total); i++) {
				list[list_cnt] = 0;
				list_cnt++;
				total++;
			}
			p_count++;
		}
	}
	print_simulation(list, list_cnt,p);

}

void print_simulation(int list[],int list_cnt,int p_num) {
	int i,j;
	for (i = 0; i < p_num; i++) {
		printf("%d번 프로세스: ", i+1);

		for (j = 0; j < list_cnt; j++) {
			if (list[j] == i + 1) {
				printf("■");
			}
			else if(list[j]==1){
				printf("ㅁ");
			}
			else{
				printf("ㅁ");
			}
		}
		printf("\n");
	}
}

void init(Pro *proc_arr, int p) {
	int i;
	for (i = 0; i < p_num; i++) {
		proc_arr[i].process_t = 0;
	}
}



