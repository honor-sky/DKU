/*
 * *	DKU Operating System Lab
 * *	    Lab1 (Scheduler Algorithm Simulator)
 * *	    Student id : 32200327  
 * *	    Student name : 김경민 
 * *
 * *   lab1_sched_types.h :
 * *       - lab1 header file.
 * *       - must contains scueduler algorithm function's declations.
 * *
 * */



#ifndef _LAB1_HEADER_H
#define _LAB1_HEADER_H


typedef struct _process Pro;
void FCFS(Pro *proc_arr, int p);
int arrival_sort(const void* a, const void* b);
void print_simulation(int list[], int list_cnt, int p_num);
void SPN(Pro *proc_arr, int p);
void RR(Pro *proc_arr, int p, int Q);
void HRRN(Pro *proc_arr, int p);
void init(Pro *proc_arr, int p);

#endif /* LAB1_HEADER_H*/
