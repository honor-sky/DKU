/*Simple customizing shell project, Kyungmin Kim, 2021/11/02, keung903@naver.com*/
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <stdbool.h>
#include <dirent.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/stat.h>
#define COMM_SIZE 1024
#define TOK_SIZE 50


void cmd_help() {
    printf("/******Simple Shell******/\n");
    printf("You can use it just as the conventional shell\n");
    printf("help            : show this help\n");
    printf("exit            : exit this shell\n");
    printf("ls              : show all files\n");
}


//명령어 분해
void parsing(char* tokens[], char* command) {
    int token_count = 0;

    tokens[0] = strtok(command, " ");
    while (tokens[token_count] != NULL) {
        token_count++;// 자른 문자열이 나오지 않을 때까지 반복
        tokens[token_count] = strtok(NULL, " ");      // 다음 문자열을 >잘라서 포인터를 반환
    }
}

//명령어 수행
bool comm_exe(char* command) {

    char* tokens[TOK_SIZE];
    int i, child, status;
    bool back = false;

    parsing(tokens, command); //명령어 문자열 배열의 첫번재 주소 전달

      //exit실행
    if (strcmp(tokens[0], "exit\n") == 0) {
        return false;
    }
    //help 실행
    if (strcmp(tokens[0], "help\n") == 0) {
        cmd_help();
        return true;
    }
    //ls 실행
    if (strcmp(tokens[0], "ls\n") == 0) {

        DIR* dir = NULL;
        struct dirent* file = NULL;

        if ((dir = opendir(get_current_dir_name())) == NULL) {
            printf("current directory error\n");
            exit(1);
        }
        while ((file = readdir(dir)) != NULL)
        {
            printf("%s\n", file->d_name);
        }
        closedir(dir);

        return true;
    }

    if ((child = fork()) == 0) {
        execvp(tokens[0], tokens);

    }
    else if (back == false) { //forward 실행인 경우 wait()로 기다림
        waitpid(child, &status, WUNTRACED);

    }
    return true;

}
//명령어를 입력받음
int main() {

    char command[COMM_SIZE];
    while (1) {

        //명령어 입력받기
        printf("%s$ ", get_current_dir_name());
        fgets(command, sizeof(command) - 1, stdin);
        if (command == NULL) {
            break;
        }
        else {
            bool re = comm_exe(command);
            if (re == false) {
                break;
            }
        }

    }
    return 0;
}
