/*mycp program, by kyungminKim, keung903@naver.com, 20211014*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/stat.h>
#define MAX_BUF 64

int main(int argc, char *argv[]){

  int fd, fdd, read_size, write_size;
  char buf[MAX_BUF];
  struct stat st;
  
  if(argc!=3){
	printf("USAGE:%sfile_name\n",argv[0]);
	exit(-1);
  }
  fd = open(argv[1],O_RDONLY);
  if(fd<0){
    printf("Can't open %sfile with error %d\n",argv[1],errno);
  }
  if(fstat(fd, &st) == -1){
     perror("fstat error");
     return 1;
  }

  fdd = open(argv[2],O_RDWR|O_CREAT|O_EXCL,st.st_mode);  
  if(fdd<0){
     printf("Can't open %sfile with error %d\n",argv[1],errno);
  }

  while(1){
    read_size = read(fd,buf,MAX_BUF);
    if(read_size==0){
	break;
    }
    write_size=write(fdd,buf,read_size);
  }
 
  close(fd);
  close(fdd);

  return 0;
}
