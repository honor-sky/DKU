/*For measuring elapsed time of the bubble sort algorithm by keung903@naver.com*/
#include <stdio.h>
#include <sys/time.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>


/*create value in array*/
void mrand(int * arr,int n) {
        int i;
        srand((unsigned)time(NULL));
        for (i = 0; i < n; i++) {
                arr[i] = ((double)rand() / 30);
        }

}

/*allocate array*/
int* array(int n) {  //배열 동적생성
        int* arr;

        arr = (int*)malloc(sizeof(int) * n);
        mrand(arr,n);

        return arr;
}

/*free array*/
void freeArray(int* arr) {
        free(arr);
}

/*print array*/
void printArray(int* arr, int n) {
        int r;

        for (r = 0; r < n; r++){
                printf("%d ", arr[r]);
        }

}

/*bubble algorithm*/
void Bubble(int* arr, int n){
        int temp;
        int i,j;

        for (i = 0; i < n - 1; i++) {
                int count=0;
                for (j = 1; j < n; j++) {
                        if (arr[j-1] > arr[j]) {
                                temp = arr[j-1];
                                arr[j-1] = arr[j];
                                arr[j] = temp;
                                count++;
                        }
                }
                if(count==0)break;
        }

}

int main(){

        struct timeval start, end, t;
        int* a;
        int arr_size =0;

        printf("배열의 크기를 입력하시오:");
        scanf("%d",&arr_size);
        printf("\n");
        a = array(arr_size);

        gettimeofday(&start,NULL);
        Bubble(a, arr_size);
        gettimeofday(&end,NULL);
        t.tv_sec = end.tv_sec - start.tv_sec;
        t.tv_usec = end.tv_usec - start.tv_usec;
        if(t.tv_usec < 0){
                t.tv_sec = t.tv_sec-1;
                t.tv_usec = t.tv_usec + 1000000;
        }

        printf("수행시간: %ldsec, %ldusec\n",t.tv_sec,t.tv_usec);
        freeArray(a);

        return 0;
}

