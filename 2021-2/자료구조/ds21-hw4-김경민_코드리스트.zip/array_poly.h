typedef struct TERM;
void append(struct TERM* poly, double coef, int expon, int arr);
void sort(struct TERM* poly, int n);
void print(struct TERM* poly, int n);
void poly_add(struct TERM* a, int asize, struct TERM* b, int bsize, struct TERM* c);
void poly_minu(struct TERM* a, int asize, struct TERM* b, int bsize, struct TERM* c);

