
int** array(int, int);
void freeArray(int**, int, int);
void printArray(int** arr, int rows, int cols, const char msg[]);

void multiplyArrays(int** res, int** a, int** b, int m, int n, int q);
void plusArrays(int** res, int** a, int** b, int m, int n);
void minusArrays(int** res, int** a, int** b, int m, int n);
void divisionArrays(int** res, int** a, int** b, int m, int n);
void transpoArrays(int** a, int m, int n);
void sparseArrays(int** a, int rows, int cols);

