int* array(int n);
void freeArray(int* arr);
void mrand(int* arr, int n);
void Insertion(int* arr, int n);
void Bubble(int* arr, int n);
void Selection(int* arr, int n);
void printArray(int* arr, int n);

