void kruskal(int(*G_matrix)[7], int* cost, int* count);
int find_parent(int a, int parent[]);
int is_cyclic(int a, int b, int parent[]);
