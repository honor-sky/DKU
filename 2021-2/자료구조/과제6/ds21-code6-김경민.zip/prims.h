void prims(int(*G_matrix)[7], int* cost, int* count);
